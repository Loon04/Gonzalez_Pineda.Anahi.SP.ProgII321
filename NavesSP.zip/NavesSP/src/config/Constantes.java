
package config;


public class Constantes {
    private static final String PATH_FILE = "src/data/";
    public static final String PATH_CSV = PATH_FILE + "NavesEspaciales.csv";
}
