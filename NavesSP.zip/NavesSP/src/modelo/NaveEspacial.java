
package modelo;

import navessp.Categoria;


public class NaveEspacial implements Comparable<NaveEspacial>{
    private int id;
    private String nombre;
    private int capaciTripulacion;
    private Categoria categoria;
    

    public NaveEspacial(int id, String nombre, int capaciTripulacion, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capaciTripulacion = capaciTripulacion;
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "id=" + id + ", nombre=" + nombre + ", capaciTripulacion=" + capaciTripulacion + ", categoria=" + categoria + '}';
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getCapaciTripulacion() {
        return capaciTripulacion;
    }
    
    public String toCSV() {
        return id + "," + nombre + "," + capaciTripulacion + "," + categoria.toString(); //por semantica, lo convierto en String a sector
        
    }
    
    @Override
    public int compareTo(NaveEspacial n) { //ordena natural
        return Integer.compare(id, n.id);
    }
    
    
}
