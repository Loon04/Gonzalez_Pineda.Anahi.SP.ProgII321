
package navessp;


public enum Categoria {
    EXPLORACION,
    CARGA,
    MILITAR
}
