package navessp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;
import modelo.NaveEspacial;


public class Inventario<T> {
    private List<T> naves = new LinkedList<>();
    Iterator<T> it = naves.iterator();
    
    public void agregar(T nave) {
        if (nave == null){
            throw new IllegalArgumentException("No puedo almacenar");
        }
        this.naves.add(nave);  
    }
    
    public void eliminar(int indice) {
        validarIndice(indice);
        naves.remove(indice);
        
        for (T nave: naves){
            System.out.println(nave);
        }
    }
    
    private void validarIndice(int indice){
        if(!(indice > 0 && indice < naves.size())){ //(indice < 0 || indice >= tamanio());
            throw new IndexOutOfBoundsException("No es valido el indice");
        }    
    }
    
    public Iterator<T> iterator(){
        if (!naves.isEmpty() && naves.get(0) instanceof Comparable){  //SI NO ESTA VACIO Y ES COMPARABLE
            return iterator((Comparator<? super T>) Comparator.naturalOrder()); //le pasmos un comparator natural
            //return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return (new ArrayList<>(naves)).iterator(); //creo una instancia nueva(lista) con los mismo elementos
    }
    
    public Iterator<T> iterator(Comparator<? super T> comparador){ //MIRA BIEN EL COMPARADOR 
        List<T> aux = new ArrayList<>(naves); //creo una instancia nueva con los mismo elementos
        aux.sort(comparador); 
        return aux.iterator();
    }
    
    public void mostrarContenido(){  //ordena por id (natural)
        System.out.println("Inventario naves: ");
        Iterator<T> it = iterator();
        while (it.hasNext()){
            System.out.println(it.next());
        }
    }
    
    public  void mostrarContenido(Comparator<? super T> comparador){ 
        System.out.println("Inventario naves: ");
        Iterator<T> it = iterator(comparador);
        while (it.hasNext()){
            System.out.println(it.next());
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) { //criterio es una clase de tipo predicate
        List<T> toReturn = new ArrayList<>(); //puede ser cualquier nombre
        for(T nave : naves){
            if(criterio.test(nave)){ //si devuelve false el item no pasa el filtro
                toReturn.add(nave);
            }
        }
        return toReturn;   
    }
    
    
}
