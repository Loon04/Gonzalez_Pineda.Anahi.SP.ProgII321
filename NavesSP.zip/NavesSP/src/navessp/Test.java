package navessp;

import modelo.NaveEspacial;
import config.Constantes;

public class Test {

    public static void main(String[] args) {
        Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
        
        inventarioNaves.agregar(new NaveEspacial(1,"USS Enterprice",50,Categoria.EXPLORACION));
        inventarioNaves.agregar(new NaveEspacial(3,"Falcon 21",20,Categoria.MILITAR));
        inventarioNaves.agregar(new NaveEspacial(2,"X-WING",2,Categoria.MILITAR));
        inventarioNaves.agregar(new NaveEspacial(5,"USS Enterprice 2",60,Categoria.EXPLORACION));
        inventarioNaves.agregar(new NaveEspacial(4,"Aerial",35,Categoria.CARGA));
        
        //por orden natural
        inventarioNaves.mostrarContenido();
        
        
        //con un comparator
        inventarioNaves.mostrarContenido((n1,n2) -> Integer.compare(n1.getCapaciTripulacion(), n2.getCapaciTripulacion())); //buscar
        
        
        System.out.println("Naves de la categoria MILITAR:");
            inventarioNaves.filtrar(n ->  n.getCategoria().equals(Categoria.MILITAR))
                .forEach(nave -> System.out.println(nave));
        
        
       
         
        
    }
    
}
